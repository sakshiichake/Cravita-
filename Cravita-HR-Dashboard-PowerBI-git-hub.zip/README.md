# Cravita HR Decision Dashboard (Power BI Project)

Power BI Desktop version of the Cravita Employee Performance dashboard (synthetic data, 100 employees, Jul 2025 – Jun 2026).

## Contents
- `Cravita_HR_Dashboard.pbip` – open this in Power BI Desktop
- `Cravita_HR_Dashboard.SemanticModel/` – data model (TMDL): tables, relationships, calculated columns, DAX measures
- `Cravita_HR_Dashboard.Report/` – 4 report pages (Overview, Departments, Employee detail, Action list)
- `data/` – `Employee_Scorecard.csv` (100 rows), `Monthly_Score.csv` (1,200 rows)

## Open it
1. Power BI Desktop (latest). If it asks, enable Options > Preview features > Power BI Project (.pbip) save option, then restart.
2. File > Open > `Cravita_HR_Dashboard.pbip`.
3. Home > Transform data > Edit parameters: set `DataFolder` to the full path of the `data` folder, ending with `\`. Apply and Refresh.
4. Check: Employees = 100, Average score = 82.7, Stars = 10, Low band = 17, High risk = 7.
5. File > Save as > `.pbix` if you need a single file. Publish: Home > Publish.

## Logic (same as the report)
Perf band: High >= 85, Low < 75. Potential band: High >= 68, Low < 56. Attrition risk: 3 signals = High, 2 = Medium.
Lists: Promote 5 = top Stars by score; Train 10 = lowest scores in Low band; Talk 5 = High-risk with largest score drop.

## Push to GitHub
    git clone https://github.com/sakshiichake/Cravita-technology-HR-Dashbord.git
    # copy the contents of this folder into the cloned folder, then:
    git add . && git commit -m "Add Power BI project" && git push
